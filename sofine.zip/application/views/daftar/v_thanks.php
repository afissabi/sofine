<div class="container">
    <div class="page-banner home-banner">
    <div class="row align-items-center flex-wrap-reverse h-100">
        <div class="col-md-6 py-5 wow fadeInLeft">
        <h1 class="mb-4">Terima Kasih...</h1>
        <p class="text-lg text-grey mb-5">Tim kami akan mereminder jadwal perawatan anda...</p>
        <a href="<?= base_url() ?>" class="btn btn-primary btn-split">Kembali <div class="fab"><span class="mai-home"></span></div></a>
        </div>
        <div class="col-md-6 py-5 wow zoomIn">
        <div class="img-fluid text-center">
            <img src="../assets/img/banner_image_1.svg" alt="">
        </div>
        </div>
    </div>
    
    </div>
</div>