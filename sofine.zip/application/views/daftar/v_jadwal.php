<!-- ======= Services Section ======= -->
<section id="services" class="services section-bg" style="margin-top: 35px;">
  <div class="container" data-aos="fade-up">
    <div class="section-title">
      <h2>Pilih Jadwal</h2>
    </div>

    <div class="row">
        <div id="calendarIO"></div>
    </div>
    <div class="row">
        <h5>Pilih Jam :</h5>
        <div class="row" id="pilihjam">
            
        </div>
    </div>

  </div>
</section><!-- End Services Section -->
