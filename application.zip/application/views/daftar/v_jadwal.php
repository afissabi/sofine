<div class="page-section banner-seo-check">
    <div class="wrap bg-image" style="background-image: url(../assets/img/bg_pattern.svg);">
    <div class="container text-center">
        <div class="row justify-content-center wow fadeInUp">
            <div class="col-lg-8">
                <h2 class="mb-4" id="posisi">Pilih Jadwal</h2>
            </div>
        </div>
    </div>
    </div>
</div>

<div class="page-section">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="widget-box">
                    <div id="calendarIO"></div>
                </div>
                <div class="widget-box">
                    <h5>Pilih Jam :</h5>
                    <div class="row" id="pilihjam">
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>