<div id="pendaftaran" class="about-us section" style="background: url(assets/images/bg.png);margin-top: 100px;">
    <div class="container">
        <div class="row">

            <div class="col-lg-6 align-self-center wow fadeInRight" data-wow-duration="1s" data-wow-delay="0.5s">
                <div class="section-heading">
                    <h6>Sofine dental & beauty studio</h6>
                    <h2>Pendaftaran Online Pasien</h2>
                </div>
                <p></p>
                <div class="main-green-button"><a href="<?php echo site_url('home/pilih_layanan') ?>"><i class="fa fa-pencil"></i> &nbsp;Daftar Sekarang</a></div>
            </div>
            <div class="col-lg-6">
                <div class="left-image wow fadeInLeft" data-wow-duration="1s" data-wow-delay="0.5s">
                    <img src="<?php echo base_url(); ?>assets/images/front.png" alt="">
                </div>
            </div>
        </div>
    </div>
</div>