<!-- ======= Services Section ======= -->
<section id="services" class="services section-bg" style="margin-top: 35px;background-image: url(<?php echo base_url() . 'assets/img/bg_jadwal.svg'; ?>);background-repeat-y: repeat;background-size: cover;background-position: center;">
  <div class="container" data-aos="fade-up">
    <div class="section-title">
      <h2>Pilih Jadwal</h2>
    </div>

    <div class="row">
      <div class="icon-box" style="transition: none;transform: none;">
        <div id="calendarIO"></div>
      </div>
    </div>
    <div class="row">
      <div class="icon-box" style="transition: none;transform: none;">
        <h5>Pilih Jam :</h5>
        <div class="row" id="pilihjam">

        </div>
      </div>
    </div>

  </div>
</section><!-- End Services Section -->