<div id="pricing" class="pricing-tables" style="background-image: url(assets/images/bg.svg);">
    <div class="container">
        <div class="row">
            <div class="col-lg-8 offset-lg-2">
                <div class="section-heading">
                    <h4>TERIMA KASIH...</h4>
                    <img src="assets/images/heading-line-dec.png" alt="">
                    <p>Kami akan menghubungi anda kembali pada hari pelayanan... <a href="<?php echo site_url() ?>">Kembali ke Halaman Awal</a</p> </div> </div> </div> </div> </div>